CREATE TABLE public.supervisor_mapping (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 representante text NOT NULL,
 representante_key text NOT NULL UNIQUE,
 supervisor text NOT NULL CHECK (supervisor IN ('ALMIR NETO', 'FERNANDO NOGUCHI', 'KAM', 'PATRICIA CARDOSO', 'SHEYLA MACEDO', 'Sem Supervisor')),
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.supervisor_mapping TO service_role;
ALTER TABLE public.supervisor_mapping ENABLE ROW LEVEL SECURITY;