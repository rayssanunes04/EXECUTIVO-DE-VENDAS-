DROP POLICY IF EXISTS "Public read upload_logs" ON public.upload_logs;
DROP POLICY IF EXISTS "Public read sales_records" ON public.sales_records;
DROP POLICY IF EXISTS "Public read supervisor uploads" ON public.supervisor_uploads;
DROP POLICY IF EXISTS "Public read monthly_history" ON public.monthly_history;
REVOKE ALL ON public.upload_logs, public.sales_records, public.supervisor_uploads, public.monthly_history FROM anon, authenticated;