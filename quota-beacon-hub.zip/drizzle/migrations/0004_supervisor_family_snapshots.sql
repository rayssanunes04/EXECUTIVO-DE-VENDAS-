CREATE TABLE public.supervisor_uploads (
 supervisor text PRIMARY KEY,
 rows jsonb NOT NULL DEFAULT '[]'::jsonb,
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.supervisor_uploads TO anon, authenticated;
GRANT ALL ON public.supervisor_uploads TO service_role;
ALTER TABLE public.supervisor_uploads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read supervisor uploads" ON public.supervisor_uploads FOR SELECT TO anon, authenticated USING (true);
COMMENT ON TABLE public.supervisor_mapping IS 'DEPRECATED: representative-only mappings replaced by family memberships derived from supervisor_uploads';