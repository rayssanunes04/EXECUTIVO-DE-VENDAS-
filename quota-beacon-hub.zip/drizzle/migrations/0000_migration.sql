CREATE TABLE public.sales_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canal text, ano integer, supervisor text, gerente text, representante text,
  cliente text, familia text,
  meta numeric NOT NULL DEFAULT 0, faturamento numeric NOT NULL DEFAULT 0, atingimento numeric,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.sales_records TO anon, authenticated;
GRANT ALL ON public.sales_records TO service_role;
ALTER TABLE public.sales_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read sales_records" ON public.sales_records FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.monthly_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canal text, ano integer, mes text, mes_ordem integer,
  faturamento_liquido numeric NOT NULL DEFAULT 0, meta_restante numeric NOT NULL DEFAULT 0,
  percentual_atingimento numeric
);
GRANT SELECT ON public.monthly_history TO anon, authenticated;
GRANT ALL ON public.monthly_history TO service_role;
ALTER TABLE public.monthly_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read monthly_history" ON public.monthly_history FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.upload_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  total_meta numeric NOT NULL DEFAULT 0, total_faturamento numeric NOT NULL DEFAULT 0
);
GRANT SELECT ON public.upload_logs TO anon, authenticated;
GRANT ALL ON public.upload_logs TO service_role;
ALTER TABLE public.upload_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read upload_logs" ON public.upload_logs FOR SELECT TO anon, authenticated USING (true);

CREATE INDEX idx_sales_canal_ano ON public.sales_records (canal, ano);
CREATE INDEX idx_history_canal_ano ON public.monthly_history (canal, ano, mes_ordem);